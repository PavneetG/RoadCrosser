// The "Launch" class.
public class Launch
{
    public static void main (String[] args)
    {
	new roadcrosser.LoginMenu();
    } // main method
} // Launch class
